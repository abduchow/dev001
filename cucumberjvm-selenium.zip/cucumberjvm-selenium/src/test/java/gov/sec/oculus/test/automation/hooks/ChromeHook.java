package gov.sec.oculus.test.automation.hooks;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

/**
 * 
 * @author yassint
 *
 */
public class ChromeHook  {

	private static WebDriver driver = null;
	
	public ChromeHook() {
		System.setProperty("webdriver.chrome.driver", new File("src/test/resources/SeleniumWebdrivers/chromedriver.exe").getAbsolutePath());
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("useAutomationExtension", false);
		driver = new ChromeDriver(options);
	}
	
	public WebDriver getDriver() {
		return driver;
	}
}
