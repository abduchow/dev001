package gov.sec.oculus.test.automation.hooks;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * 
 * @author yassint
 *
 */
public class InternetExplorerHook {
private static WebDriver driver = null;
	
	 public InternetExplorerHook() {
		System.setProperty("webdriver.ie.driver", new File("src/test/resources/SeleniumWebdrivers/IEDriverServer.exe").getAbsolutePath());
		DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
		ieCapabilities.setCapability("nativeEvents", false);
		ieCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
		ieCapabilities.setCapability("ignoreProtectedModeSettings", true);
		ieCapabilities.setCapability("disable-popup-blocking", true);
		ieCapabilities.setCapability("enablePersistentHover", true);
		ieCapabilities.setCapability("ignoreZoomSetting", true);

		// deprecated but working
		driver = new InternetExplorerDriver(ieCapabilities);
	}
	
	public WebDriver getDriver() {
		return driver;
	}
}
