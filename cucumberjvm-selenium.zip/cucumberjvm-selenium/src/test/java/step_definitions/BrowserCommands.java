package step_definitions;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class BrowserCommands{
   
	
	public WebDriver driver;
    public BrowserCommands()
    {
    	driver = Hooks.driver;
    }

    @Given("^Open EDGARLogin website$")
    public void open_EDGARLogin_website() throws Throwable 
    {
    	driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
       	//e5 URL
        driver.get("https://filer-edgar-janeway.apps.edg-stg.sec.gov/Welcome/EDGARLogin.htm"); 
    	
    	//UAT URL
    	//driver.get("https://penny.edgarfiling.sec.gov/Welcome/EDGARLogin.htm");
     }

    @Given("^Filer Enter a valid  CIK and Password$")
    public void filer_Enter_a_valid_CIK_and_Password() throws Throwable 
    {

    	driver.findElement(By.id("cik")).sendKeys("0001684376");  //0001684461 e5 = 0001684376		
        driver.findElement(By.id("password")).sendKeys("ivvtest@1234");        

    }

    @Given("^Click Lonin to EDGAR HomePage$")
    public void click_Lonin_to_EDGAR_HomePage() throws Throwable 
    {
        driver.findElement(By.name("Logon")).click();
    	driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);
    }

    @Given("^Click EDGARLink Online Form Submission$")
    public void click_EDGARLink_Online_Form_Submission() throws Throwable 
    {   	
        driver.switchTo().frame("left_iframe");
    	driver.findElement(By.xpath("//a [@target='EDGAR Main Frame']//font[contains(text(), 'EDGARLink Online Form Submission')]")).click();

    }
    
    
    @Given("^Go to Submission Types Select (\\d+)-k type$")
    public void go_to_Submission_Types_Select_k_type(int arg1) throws Throwable 
    {
        driver.switchTo().parentFrame();
        driver.switchTo().frame("right_iframe");
        driver.findElement(By.xpath("//select[@id='form:formType']//option[@value='8-K']")).click();
   
    }

    @When("^Click 'Go to From' button filer able to see (\\d+)-k From HomePage$")
    public void click_Go_to_From_button_filer_able_to_see_k_From_HomePage(int arg1) throws Throwable 
    {
        driver.findElement(By.xpath("//*[@id=\"form:submitButton\"]")).click();

    }

    @Then("^Filer input all Required field in Main page$")
    public void filer_input_all_Required_field_in_Main_page() throws Throwable {
        //Filer CIKSEC 
        driver.findElement(By.xpath("//*[@id=\"form:filerCik\"]")).sendKeys("0001684376");
 
        
        //Filer CCC

        driver.findElement(By.xpath("//*[@id=\"form:filerCcc\"]")).sendKeys("test@123");

        
         Thread.sleep(5000);
        //Emerging Growth Company
        driver.findElement(By.xpath("//select[@id='form:eGCompany']")).click();
        Thread.sleep(5000); 
    	//driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);

        driver.findElement(By.xpath("//select[@id='form:eGCompany']//option[@value='Yes']")).click();
   
              
        driver.findElement(By.xpath("//select[@id='form:exTransitionPeriodList']")).click(); 
         
        
       //Elected not to use the extended transition period for complying with any new or revised financial accounting standards
        driver.findElement(By.xpath("//select[@id='form:exTransitionPeriodList']//option[@value='Yes']")).click();
       
        
        //Period
        driver.findElement(By.xpath("//*[@id=\"form:periodDateInputDate\"]")).sendKeys("05-19-2020");
        Thread.sleep(5000);

       
       	//Items
        driver.findElement(By.xpath("//*[@id=\"form:coregItems_table:0:j_id199\"]/img[1]")).click();
        
       	driver.findElement(By.xpath("//*[@id=\"form:coregItems_table:0:j_id199\"]/img[1]")).sendKeys("1.01"); // only for IE
       
       	driver.findElement(By.xpath("//*[@id=\"form:coregItems_table:0:targetSuggestion2:suggest\"]/tbody/tr[31]/td[2]")).click();

    }

    @Then("^Filer add Requried documents in Documnets page$")
    public void filer_add_Requried_documents_in_Documnets_page() throws Throwable {
       

    	//Add Document
    	driver.findElement(By.xpath("//*[@id=\"form:DocumentSection_lbl\"]")).click();
      	

    	//Attached Documents List home page
        driver.findElement(By.xpath("//img[@id=\"form:AddAttachment2\"]")).click();
        

      //Attachment Selection and Upload
        driver.findElement(By.xpath("//input[@name='uploadForm:attachFileUpload']")).click();

        //open upload window  upload.click(); put path to your image in a clipboard 
        StringSelection ss = new StringSelection("C:\\EDGARAutomation\\cucumberjvm-selenium\\Document\\edgar_01.txt");
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
    	Thread.sleep(4000);
        //imitate mouse events like ENTER, CTRL+C, CTRL+V
        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
    	Thread.sleep(4000);

        driver.findElement(By.xpath("//select[@name='form:doc_table:0:docType8K']")).click();
    	Thread.sleep(4000);
        driver.findElement(By.xpath("//*[@id=\"form:doc_table:0:docType8K\"]//option[@value='8-K']")).click();
    }

    @Then("^Filer click Submit button$")
    public void filer_click_Submit_button() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        driver.findElement(By.xpath("//*[@id=\"form:Submit888\"]")).click();
    }

    @Then("^Click LIVE Submit$")
    public void click_LIVE_Submit() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^Save accession number for this submission$")
    public void save_accession_number_for_this_submission() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("^Open WORKSTATION LOGIN website$")
    public void open_WORKSTATION_LOGIN_website() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("^EDGAR SEC  Enter a valid  UserName and Password$")
    public void edgar_SEC_Enter_a_valid_UserName_and_Password() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Given("^Click Lonin to EDGAR SEC WORKSTATION$")
    public void click_Lonin_to_EDGAR_SEC_WORKSTATION() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^EDGAR User Inbox Page well be Display$")
    public void edgar_User_Inbox_Page_well_be_Display() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^Go to OFIS dropdown list seletct OFIS Submission Query$")
    public void go_to_OFIS_dropdown_list_seletct_OFIS_Submission_Query() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^Enter your Accession number in Accession No\\.: field$")
    public void enter_your_Accession_number_in_Accession_No_field() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    }

    @Then("^Click Execte Button to see the OFIS Submission Query Results$")
    public void click_Execte_Button_to_see_the_OFIS_Submission_Query_Results() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

    } 
    
    
    
    
    
    
}
