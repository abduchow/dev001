package step_definitions;

import java.io.File;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import gov.sec.oculus.test.automation.hooks.ChromeHook;
import gov.sec.oculus.test.automation.hooks.InternetExplorerHook;

import org.openqa.selenium.remote.DesiredCapabilities;

public class Hooks {
	public static WebDriver driver;

	@Before
	/**
	 * Delete all cookies at the start of each scenario to avoid shared state
	 * between tests
	 */

	public void openBrowser() throws MalformedURLException {
		System.out.println("Called openBrowser");

		// WebDriver driver = new InternetExplorerDriver();

		//true or false
		
		boolean ie = true;
		if (!ie) {
			
			driver = new ChromeHook().getDriver();
		} else {
			driver = new InternetExplorerHook().getDriver();
	
		}
		// Set browser defaults (maximise, clear cookies, set timeouts)
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.MINUTES);
		driver.manage().timeouts().pageLoadTimeout(2, TimeUnit.MINUTES);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
	}

	// @After
	/**
	 * Embed a screenshot in test report if test is marked as failed
	 */
	 public void embedScreenshot(Scenario scenario) {
	
	 if(scenario.isFailed()) {
	 try {
	 scenario.write("Current Page URL is " + driver.getCurrentUrl());
	// byte[] screenshot = getScreenshotAs(OutputType.BYTES);
	 byte[] screenshot =
	 ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);
	 scenario.embed(screenshot, "image/png");
	 } catch (WebDriverException somePlatformsDontSupportScreenshots) {
	 System.err.println(somePlatformsDontSupportScreenshots.getMessage());
	 }
	
	 }

	 driver.quit();
	 }

}